package Robot;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.util.List;

public class JobRobot {

    public static void humanType(WebDriver driver, WebElement element, String text) throws InterruptedException {
        for (char ch : text.toCharArray()) {
            element.sendKeys(Character.toString(ch));
            Thread.sleep((long) (Math.random() * 200 + 50));
        }
    }

    public static void main(String[] args) throws InterruptedException {
        WebDriverManager.chromedriver().setup();

        WebDriver driver = new ChromeDriver();
        WebDriverWait wait = new WebDriverWait(driver, 10);

        try {
            driver.get("https://www.clasificadosonline.com/empleos/");

            WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("/html/body/div[4]/table/tbody/tr[3]/td/div[2]/form/div[2]/div[1]/input[1]")));
            humanType(driver, searchBox, "QA");

            WebElement searchButton = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("/html/body/div[4]/table/tbody/tr[3]/td/div[2]/form/div[2]/div[1]/input[3]")));
            searchButton.click();

            String originalWindowHandle = driver.getWindowHandle();
            int jobIndex = 0;

            while (true) {
                List<WebElement> jobLinks = wait.until(ExpectedConditions
                        .presenceOfAllElementsLocatedBy(By.xpath("//a[div[@class='esp' and text()='Solicitar']]")));

                if (jobIndex >= jobLinks.size()) {
                    break;
                }

                WebElement jobLink = jobLinks.get(jobIndex);
                jobLink.click();

                for (String handle : driver.getWindowHandles()) {
                    if (!handle.equals(originalWindowHandle)) {
                        driver.switchTo().window(handle);
                        break;
                    }
                }

                wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("#ctl00_mc_From")));
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("document.querySelector('#ctl00_mc_From').value='91pixelsusa@gmail.com';");

                WebElement messageBox = wait.until(ExpectedConditions.elementToBeClickable(
                        By.xpath("/html/body/center/div/form/table/tbody/tr[2]/td/div[2]/div[4]/div[2]/textarea")));
                humanType(driver, messageBox,
                        "Any questions about my portfolio or resume, feel free to contact me. Thank you!");

                WebElement fileInput = wait.until(ExpectedConditions.elementToBeClickable(
                        By.xpath("/html/body/center/div/form/table/tbody/tr[2]/td/div[2]/div[5]/div[2]/input")));
                fileInput.sendKeys("C:\\Users\\MichaelACamacho\\Desktop\\Recibo Certificacion.pdf");

                WebElement sendButton = wait.until(ExpectedConditions.elementToBeClickable(
                        By.xpath("/html/body/center/div/form/table/tbody/tr[2]/td/div[2]/div[8]/center/input")));

                try {
                    sendButton.click();
                } catch (Exception e) {
                    Actions actions = new Actions(driver);
                    actions.moveToElement(sendButton).click().build().perform();
                }

                // Handle the manual captcha resolution
                System.out.println("Please solve the captcha. The script will continue once it's resolved.");
                wait.until(ExpectedConditions.urlToBe("https://www.clasificadosonline.com/Gracias.asp"));

                driver.close(); // Close the active window.
                driver.switchTo().window(originalWindowHandle);
                jobIndex++;
            }

        } finally {
            Thread.sleep(60000); // 60 seconds pause
            driver.quit();
        }
    }
}
